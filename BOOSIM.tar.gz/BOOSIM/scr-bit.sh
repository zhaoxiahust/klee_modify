#!/bin/bash
printf "\n" >new-dor-all-bit.log
i=0.01
int=0.01
while [ 1 -eq "$(echo "$i < 0.4"| bc)" ]
do
	sed -n '/injection_rate/p' examples/mesh88_bit
	./booksim examples/mesh88_bit | tail -n 30 >> new-dor-all-bit.log
	ii="0"`echo "scale=2; ${i} + ${int}" | bc`
	sed -i "/injection_rate/s/$i/$ii/" examples/mesh88_bit
	i=$ii
done

sed -i "/injection_rate/s/$i/0\.01/" examples/mesh88_bit
echo All complete!
