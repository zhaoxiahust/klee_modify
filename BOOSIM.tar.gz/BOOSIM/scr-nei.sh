#!/bin/bash
printf "\n" >fpin3-nei.log
i=0.01
int=0.02
while [ 1 -eq "$(echo "$i < 1"| bc)" ]
do
	sed -n '/injection_rate/p' examples/mesh88_nei
	./booksim examples/mesh88_nei | tail -n 30 >> fpin3-nei.log
	ii="0"`echo "scale=2; ${i} + ${int}" | bc`
	sed -i "/injection_rate/s/$i/$ii/" examples/mesh88_nei
	i=$ii
done

sed -i "/injection_rate/s/$i/0\.01/" examples/mesh88_nei
echo All complete!
