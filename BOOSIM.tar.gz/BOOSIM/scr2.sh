#!/bin/bash
printf "\n" >new-dyxy-all-uni.log
i=0.01
int=0.01
while [ 1 -eq "$(echo "$i < 0.52"| bc)" ]
do
	sed -n '/injection_rate/p' examples/mesh88_lat2
	./booksim examples/mesh88_lat2 | tail -n 30 >> new-dyxy-all-uni.log
	ii="0"`echo "scale=2; ${i} + ${int}" | bc`
	sed -i "/injection_rate/s/$i/$ii/" examples/mesh88_lat2
	i=$ii
done

sed -i "/injection_rate/s/$i/0\.01/" examples/mesh88_lat2
echo All complete!
