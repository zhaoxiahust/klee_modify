// $Id: islip.cpp 5188 2012-08-30 00:31:31Z dub $

/*
 Copyright (c) 2007-2012, Trustees of The Leland Stanford Junior University
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice, this 
 list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "booksim.hpp"
#include <iostream>

#include "routingaware.hpp"
#include "random_utils.hpp"

//#define DEBUG_ISLIP

RoutingAware_Sparse::RoutingAware_Sparse( Module *parent, const string& name,
			    int inputs, int outputs, int iters ) :
  SparseAllocator( parent, name, inputs, outputs ),
  _RoutingAware_iter(iters)
{
  _gptrs.resize(_outputs, 0);
  _aptrs.resize(_inputs, 0);
}

void RoutingAware_Sparse::Allocate( )
{
  int input;
  int output;

  int input_offset;
  int output_offset;

  map<int, sRequest>::iterator p;
  bool wrapped;


//////////////////////////////////////////////////////////////////////////////////////////////////////////  
// Packet Chaining

  for ( int out = 0; out < _outputs; ++out ) {
    if ( _outmatch_last[out] != -1 ) {
      int in = _outmatch_last[out];

      if ( ( !( _out_req[out].empty( ) ) ) && ( ( !(_in_req[in].empty( ) ) ) ) ) {
        bool inmatchedflag = 0, outmatchedflag = 0;
        p = _in_req[in].begin( );
        while( p != _in_req[in].end( ) ) {
          if ( out == p->second.port ) {
            outmatchedflag = 1;
            break;
            //exit if error
          }            
	  p++;
          //cout<<p->port<<"  ";
        }
        //cout<<endl;

        p = _out_req[out].begin( );
        while( p != _out_req[out].end( ) ) {
          if ( in == p->second.port ) {
            inmatchedflag = 1;
            break;
          }            
	  p++;
         // cout<<p->port<<"  ";
        }
        //cout<<endl;

        if ( ( inmatchedflag == 1 ) && ( outmatchedflag == 1 ) && ( _footprint_matrix[input][output] == 0 ) ) {
          _outmatch[out] = in;  
          _inmatch[in] = out;  
	  //_gptrs[out] = ( in + 1 ) % _inputs;
	  //_aptrs[in]  = ( out + 1 ) % _outputs;       
          //cout<<_outputs<<"  "<<_inputs<<"  "<<in<<"  "<<out<<endl;
        }

      }
    }
  }
  //cout<<endl;


  for ( output = 0; output < _outputs; ++output ) {
    _outmatch_last[output] = -1;
  }
  for ( input = 0; input <_inputs; ++input ) {
    _inmatch_last[input] = -1;
  }

// Packet Chaining
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




  //************************************************************************************************************
  // below add for ts-router
/*
  int choice[_inputs][_outputs];
  for ( int i = 0; i < _inputs; i++ ) {
    for ( int k = 0; k < _outputs; k++ ) {
      choice[i][k] = 0;
    }
  }
  for ( int i = 0; i < _inputs; i++ ) {
    for ( int k = 0; k < _outputs; k++ ) {
      if ( _request_matrix[i][k] > 0 ) {
        for ( int t = 0; t < _inputs; t++ ) {
          choice[t][k]++;
        }
        for ( int t = 0; t < _inputs; t++ ) {
          choice[i][t]++;
        }
        choice[i][k] = choice[i][k] - 2;
      }
    }
  }

  for ( int in = 0; in < _inputs; ++in ) {
    if ( !( _in_req[in].empty( ) ) ) {
      int outport = 0;
      p = _in_req[in].begin( );
      while( p != _in_req[in].end( ) ) {
        outport = p->second.port;
        choice[in][outport] = choice[in][outport] + 1000;
        p++;
      }
    }
  }
//choice match based on the vcchaining-router priority matrix
  
  for ( int in = 0; in < _inputs; in++ ) {
    for ( int out = 0; out < _outputs; out++ ) {
      if ( choice[in][out] > 1000 ) {
        int flag = 0;
        for ( int i = 0; i < _inputs; ++i ) {
          if ( choice[i][out] > choice[in][out] ) {
            flag = 1;
            break;
          }
        }  
        for ( int k = 0; k < _outputs; ++k ) {
          if ( choice[in][k] > choice[in][out] ) {
            flag = 1;
            break;
          }
        }
        if ( flag == 0 ) {
          if ( ( _outmatch[out] == -1 ) && ( _inmatch[in] == -1 ) && ( _footprint_matrix[input][output] == 0 ) ) {
            _outmatch[out] = in;  
            _inmatch[in] = out; 
            for ( int i = 0; i < _inputs; ++i ) {
              choice[i][out] = 0;
            }  
            for ( int k = 0; k < _outputs; ++k ) {
              choice[in][k] = 0;
            } 
            //cout<<_inputs<<" "<<_outputs<<" "<<in<<" "<<out<<endl;
          }          
        } 
      }
    }
  }
 
*/
  // above add for ts-router
  //**************************************************************************************************************



  for ( int iter = 0; iter < _RoutingAware_iter; ++iter ) {
    // Grant phase

    vector<int> grants(_outputs, -1);

    for ( output = 0; output < _outputs; ++output ) {

      int footflag = 0;
      for ( int inputf = 0; inputf < _inputs; inputf++ ) {
        if ( _footprint_matrix[inputf][output] > 0 ) {
          footflag = 1;
          break;
        }
      }
      footflag = 0;


      // Skip loop if there are no requests
      // or the output is already matched
      if ( ( _out_req[output].empty( ) ) ||
	   ( _outmatch[output] != -1 ) ||
	   ( footflag == 1 ) ) {
	continue;
      }

      // A round-robin arbiter between input requests
      input_offset = _gptrs[output];

      p = _out_req[output].begin( );
      while( ( p != _out_req[output].end( ) ) &&
	     ( p->second.port < input_offset ) ) {
	p++;
      }

      wrapped = false;
      while( (!wrapped) || 
	     ( ( p != _out_req[output].end( ) ) &&
	       ( p->second.port < input_offset ) ) ) {
	if ( p == _out_req[output].end( ) ) {
	  if ( wrapped ) { break; }
	  // p is valid here because empty lists
	  // are skipped (above)
	  p = _out_req[output].begin( );
	  wrapped = true;
	}

	input = p->second.port;

	// we know the output is free (above) and
	// if the input is free, grant request
	if ( ( _inmatch[input] == -1 ) && ( _footprint_matrix[input][output] < 2 ) ) {
	//if ( ( _inmatch[input] == -1 ) ) {
	  grants[output] = input;
	  break;
	}

	p++;
      }      
    }

#ifdef DEBUG_RoutingAware
    cout << "grants: ";
    for ( int i = 0; i < _outputs; ++i ) {
      cout << grants[i] << " ";
    }
    cout << endl;

    cout << "aptrs: ";
    for ( int i = 0; i < _inputs; ++i ) {
      cout << _aptrs[i] << " ";
    }
    cout << endl;
#endif

    // Accept phase

    for ( input = 0; input < _inputs; ++input ) {

      if ( _in_req[input].empty( ) ) {
	continue;
      }

      // A round-robin arbiter between output grants
      output_offset = _aptrs[input];

      p = _in_req[input].begin( );
      while( ( p != _in_req[input].end( ) ) &&
	     ( p->second.port < output_offset ) ) {
	p++;
      }

      wrapped = false;
      while( (!wrapped) || 
	     ( ( p != _in_req[input].end( ) ) &&
	       ( p->second.port < output_offset ) ) ) {
	if ( p == _in_req[input].end( ) ) {
	  if ( wrapped ) { break; }
	  // p is valid here because empty lists
	  // are skipped (above)
	  p = _in_req[input].begin( );
	  wrapped = true;
	}

	output = p->second.port;

	// we know the output is free (above) and
	// if the input is free, grant request
	if ( grants[output] == input && ( _footprint_matrix[input][output] < 2 ) ) {
        //if ( grants[output] == input ) {
	  // Accept
	  _inmatch[input]   = output;
	  _outmatch[output] = input;
         
          
          _inmatch_last[input] = _inmatch[input]; // add for packet chaining
          _outmatch_last[output] = _outmatch[output]; // add for packet chaining


	  // Only update pointers if accepted during the 1st iteration
	  if ( iter == 0 ) {
	    _gptrs[output] = ( input + 1 ) % _inputs;
	    _aptrs[input]  = ( output + 1 ) % _outputs;
	  }

	  break;
	}

	p++;
      } 
    }

//*******************************************************************
// add for routing aware switching
// for normal islip

    
    grants.resize(_inputs, -1);   

    for ( output = 0; output < _outputs; ++output ) {

      // Skip loop if there are no requests
      // or the output is already matched
      if ( ( _out_req[output].empty( ) ) ||
	   ( _outmatch[output] != -1 ) ) {
	continue;
      }

      // A round-robin arbiter between input requests
      input_offset = _gptrs[output];

      p = _out_req[output].begin( );
      while( ( p != _out_req[output].end( ) ) &&
	     ( p->second.port < input_offset ) ) {
	p++;
      }

      wrapped = false;
      while( (!wrapped) || 
	     ( ( p != _out_req[output].end( ) ) &&
	       ( p->second.port < input_offset ) ) ) {
	if ( p == _out_req[output].end( ) ) {
	  if ( wrapped ) { break; }
	  // p is valid here because empty lists
	  // are skipped (above)
	  p = _out_req[output].begin( );
	  wrapped = true;
	}

	input = p->second.port;

	// we know the output is free (above) and
	// if the input is free, grant request
	if ( _inmatch[input] == -1 ) {
	  grants[output] = input;
	  break;
	}

	p++;
      }      
    }

#ifdef DEBUG_RoutingAware
    cout << "grants: ";
    for ( int i = 0; i < _outputs; ++i ) {
      cout << grants[i] << " ";
    }
    cout << endl;

    cout << "aptrs: ";
    for ( int i = 0; i < _inputs; ++i ) {
      cout << _aptrs[i] << " ";
    }
    cout << endl;
#endif

    // Accept phase

    for ( input = 0; input < _inputs; ++input ) {

      if ( _in_req[input].empty( ) ) {
	continue;
      }

      // A round-robin arbiter between output grants
      output_offset = _aptrs[input];

      p = _in_req[input].begin( );
      while( ( p != _in_req[input].end( ) ) &&
	     ( p->second.port < output_offset ) ) {
	p++;
      }

      wrapped = false;
      while( (!wrapped) || 
	     ( ( p != _in_req[input].end( ) ) &&
	       ( p->second.port < output_offset ) ) ) {
	if ( p == _in_req[input].end( ) ) {
	  if ( wrapped ) { break; }
	  // p is valid here because empty lists
	  // are skipped (above)
	  p = _in_req[input].begin( );
	  wrapped = true;
	}

	output = p->second.port;

	// we know the output is free (above) and
	// if the input is free, grant request
	if ( grants[output] == input ) {
	  // Accept
	  _inmatch[input]   = output;
	  _outmatch[output] = input;
          
          _inmatch_last[input] = _inmatch[input]; // add for packet chaining
          _outmatch_last[output] = _outmatch[output]; // add for packet chaining

	  // Only update pointers if accepted during the 1st iteration
	  if ( iter == 0 ) {
	    _gptrs[output] = ( input + 1 ) % _inputs;
	    _aptrs[input]  = ( output + 1 ) % _outputs;
	  }

	  break;
	}

	p++;
      } 
    }


// add for routing aware switching
//******************************************************************************

  }

  //*********************************************************************************************************
  // below add for ts-router
  for ( int in = 0; in < _inputs; ++in ) {
    for ( int out = 0; out < _outputs; ++out ) {
      _request_matrix[in][out] = 0;
    }
  }
  // add for TS-Router
  //////////////////////////////////////////////////////////////////////////////////////////////////////////  

#ifdef DEBUG_RoutingAware
  cout << "input match: ";
  for ( int i = 0; i < _inputs; ++i ) {
    cout << _inmatch[i] << " ";
  }
  cout << endl;

  cout << "output match: ";
  for ( int j = 0; j < _outputs; ++j ) {
    cout << _outmatch[j] << " ";
  }
  cout << endl;
#endif
}
