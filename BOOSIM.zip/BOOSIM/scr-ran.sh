#!/bin/bash
printf "\n" >dyxy-all-ran.log
i=0.01
int=0.02
while [ 1 -eq "$(echo "$i < 0.52"| bc)" ]
do
	sed -n '/injection_rate/p' examples/mesh88_ran
	./booksim examples/mesh88_ran | tail -n 30 >> dyxy-all-ran.log
	ii="0"`echo "scale=2; ${i} + ${int}" | bc`
	sed -i "/injection_rate/s/$i/$ii/" examples/mesh88_ran
	i=$ii
done

sed -i "/injection_rate/s/$i/0\.01/" examples/mesh88_ran
echo All complete!
