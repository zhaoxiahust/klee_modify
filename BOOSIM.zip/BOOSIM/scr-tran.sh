#!/bin/bash
printf "\n" >dyxy-all-tran.log
i=0.01
int=0.02
while [ 1 -eq "$(echo "$i < 0.52"| bc)" ]
do
	sed -n '/injection_rate/p' examples/mesh88_tran
	./booksim examples/mesh88_tran | tail -n 30 >> dyxy-all-tran.log
	ii="0"`echo "scale=2; ${i} + ${int}" | bc`
	sed -i "/injection_rate/s/$i/$ii/" examples/mesh88_tran	
	i=$ii
done

sed -i "/injection_rate/s/$i/0\.01/" examples/mesh88_tran
echo All complete!
