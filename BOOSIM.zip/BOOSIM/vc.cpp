// $Id: vc.cpp 5188 2012-08-30 00:31:31Z dub $

/*
 Copyright (c) 2007-2012, Trustees of The Leland Stanford Junior University
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice, this 
 list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this
 list of conditions and the following disclaimer in the documentation and/or
 other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*vc.cpp
 *
 *this class describes a virtual channel in a router
 *it includes buffers and virtual channel state and controls
 *
 *This class calls the routing functions
 *
 *update priority: AddFlit, UpdatePriority
 */

#include <limits>
#include <sstream>

#include "globals.hpp"
#include "booksim.hpp"
#include "vc.hpp"

const char * const VC::VCSTATE[] = {"idle",
				    "routing",
				    "vc_alloc",
				    "active"};

VC::VC( const Configuration& config, int outputs, 
	Module *parent, const string& name )
  : Module( parent, name ), 
    _state(idle), _out_port(-1), _out_vc(-1), _pri(0), _watched(false), 
    _expected_pid(-1), _last_id(-1), _last_pid(-1)
{//Member initializer lists
//kj**************************************
  trafficP=config.GetStr("traffic");
  traffictype==config.GetStr("sim_type");
  reosys=config.GetInt("reosys");//kj

/*  if(trafficP=="shuffle")//48-33 4;35-7 9
  {
	reosrc=48;
	reodes=33;
  }
  else if(trafficP=="bitrev")
  {
	reosrc=3;
	reodes=48;
  }
  else if(trafficP=="uniform")
  {
	reosrc=55;
	reodes=10;
  }
  else if(trafficP=="transpose")//57-15,56-7
  {
	reosrc=5;
	reodes=40;
  }
  else if(trafficP=="bitcomp")
  {
	reosrc=16;
	reodes=47;
  }
  else if(trafficP=="randperm")
  {
	reosrc=4;
	reodes=57;
  }
  else if(trafficP=="neighbor")
  {
	reosrc=59;
	reodes=4;
  }
  else if(trafficP=="tornado")
  {
	reosrc=47;
	reodes=2;
  }*/
//**************************************

  _lookahead_routing = !config.GetInt("routing_delay");
  _route_set = _lookahead_routing ? NULL : new OutputSet( );

  rfName = config.GetStr("routing_function"); //kj
  string priority = config.GetStr( "priority" );
  if ( priority == "local_age" ) {
    _pri_type = local_age_based;
  } else if ( priority == "queue_length" ) {
    _pri_type = queue_length_based;
  } else if ( priority == "hop_count" ) {
    _pri_type = hop_count_based;
  }else if ( priority == "dyio" ) {//kj
    _pri_type = dyio; 
  } else if ( priority == "none" ) {//default value
    _pri_type = none;
  } else {
    _pri_type = other;
  }

  _priority_donation = config.GetInt("vc_priority_donation");
}

VC::~VC()
{
  if(!_lookahead_routing) {
    delete _route_set;
  }
}

void VC::AddFlit( Flit *f )
{
  assert(f);

  if(_expected_pid >= 0) {//防止一个packet中的flit走乱了
    if(f->pid != _expected_pid) {
      ostringstream err;
      err << "Received flit " << f->id << " with unexpected packet ID: " << f->pid 
	  << " (expected: " << _expected_pid << ")";
      Error(err.str());
    } else if(f->tail) {
      _expected_pid = -1;
    }
  } else if(!f->tail) {
    _expected_pid = f->pid;
  }
  // update flit priority before adding to VC buffer
  if(_pri_type == local_age_based) {
    f->pri = numeric_limits<int>::max() - GetSimTime();
    assert(f->pri >= 0);
  } else if(_pri_type == hop_count_based) {
    f->pri = f->hops;//跳数越大，优先级越高
    assert(f->pri >= 0);
  }
  //kj****************************
  
  int sz= _buffer.size();//不包括新插入的flit
  _buffer.push_back(f);//先进入队列再说
//  cout<<"Before***********************"<<endl;
//  Outputqueue();
  if(reosys && sz>1)
  {
	  if(f->tail)
	  {//整个packet都到了，再重排序，不然乱了
		int beg=0,src,dst;
		int hpid,findinx=0;
		hpid=_buffer[0]->pid;
		src=f->src;
		dst=f->dest;
		for(int i=1;i<sz;i++)
		{
			if(_buffer[i]->pid!=hpid)
			{//跳过第一个packet
				beg=i;
				break;
			}
		}
		if(beg)//至少有两个packet，跳过第一个packet
		{
			for(int i=beg;i<sz;i++)
			{
				if(_buffer[i]->src==src && _buffer[i]->dest==dst && f->pid<_buffer[i]->pid)
				{//是否有属于相同流，但是乱序
					findinx=i;
					break;
				}
			}
			if(findinx)
			{//存在乱序;因为这里是数组实现，所以后面的都要向后挪一格
			  //  cout<<"Before***********************"<<endl;
              //  Outputqueue();
				deque<Flit *>::iterator it=_buffer.begin();
				it+=findinx;
				Flit * temf=_buffer.back();
				while(temf->pid==f->pid)
				{
				    _buffer.pop_back();
					it=_buffer.insert(it,temf);
					temf=_buffer.back();
				}
			//	cout<<"After*************************"<<endl;
 			//	Outputqueue();
			}
		}
	  }
  	}
  
//  cout<<"After*************************"<<endl;
 // Outputqueue();
// _buffer.push_back(f);
  UpdatePriority();
//输出buffer中的flit信息
/*
  int sz= _buffer.size();
	for(int i=0;i<sz;i++)
	{
		cout<<"pid "<<_buffer[i]->pid<<" id "<<_buffer[i]->id<<",";
	}
	cout<<endl;
	*/
//*********************
}

//头flit来的时候，vc buffer除了头一个packet，其他packet都是整个的;非头flit只要跟在头flit后面就行
void VC::Reorder(int src, int dst)
{//if(traffictype=="workload")
	mp.clear();
	vt.clear();
	int sz= _buffer.size();
	int has=0, cupid=-1,ooo=0;
	for(int i=0; i<sz; i++)//遍历_buffer
	{	//针对流(src,dst)的包
		if(_buffer[i]->src==src && _buffer[i]->dest==dst)
		{
			has++;
			mp.insert(make_pair(_buffer[i]->pid, _buffer[i]));//利用map对pid排序
			vt.push_back(i);//保存index顺序
			if(cupid < _buffer[i]->pid)
			{
				cupid=_buffer[i]->pid;//应该是从小到大的顺序
			}
			else
			{
				ooo=1;//顺序不对
			}
		}
	}
	if(has>1 && ooo)
	{
		int ii=0;
		for(map<int, Flit*>::iterator iter=mp.begin(); iter!=mp.end(); iter++)
		{
			int idx=vt[ii++];
			Flit * fl=iter->second;
			_buffer[idx]=fl;
		}
	}
}


bool VC::Outputqueue()
{
    int sz= _buffer.size();
	for(int i=0;i<sz;i++)
	{
		cout<<"pid "<<_buffer[i]->pid<<" id "<<_buffer[i]->id<<",";
	}
	cout<<endl;
	return true;
}

/*
bool VC::Outputqueue()
{
    int sz= _buffer.size();
	int has=0;
	for(int i=0;i<sz;i++)
	{
		if(_buffer[i]->src==5&&_buffer[i]->dest==40)
		{
			has++;
		}
	}
	if(has>1)
	{
		cout<<"Before*******************************"<<endl;
		for(int i=0;i<sz;i++)
		{
			cout<<"src"<<_buffer[i]->src<<" dest"<<_buffer[i]->dest<<" pid"<<_buffer[i]->pid<<endl;
		}
		//Reorder();
		cout<<"After***************"<<endl;
		for(int i=0;i<sz;i++)
		{
			cout<<"src"<<_buffer[i]->src<<" dest"<<_buffer[i]->dest<<" pid"<<_buffer[i]->pid<<endl;
		}
		return true;
	}
	else
		return false;
}
*/
//********************************kj



Flit *VC::RemoveFlit( )
{
  Flit *f = NULL;
  if ( !_buffer.empty( ) ) {
    f = _buffer.front( );
    _buffer.pop_front( );//删除前面的flit
    _last_id = f->id;
    _last_pid = f->pid;
    UpdatePriority();//
  } else {
    Error("Trying to remove flit from empty buffer.");
  }
  return f;
}



void VC::SetState( eVCState s )
{
  Flit * f = FrontFlit();
  
  if(f && f->watch)
    *gWatchOut << GetSimTime() << " | " << FullName() << " | "
		<< "Changing state from " << VC::VCSTATE[_state]
		<< " to " << VC::VCSTATE[s] << "." << endl;
  
  _state = s;
}

const OutputSet *VC::GetRouteSet( ) const
{
  return _route_set;
}

void VC::SetRouteSet( OutputSet * output_set )
{
  _route_set = output_set;
  _out_port = -1;
  _out_vc = -1;
}

void VC::SetOutput( int port, int vc )
{
  _out_port = port;
  _out_vc   = vc;
}
//只在AddFlit和Removeflit中执行
void VC::UpdatePriority()
{
  if(_buffer.empty()) return;
  if(_pri_type == queue_length_based) {//priority == "none" by default
    _pri = _buffer.size();
  } else if(_pri_type != none) {
    Flit * f = _buffer.front();
    if((_pri_type != local_age_based) && _priority_donation) {//_priority_donation=0 by default
      Flit * df = f;
      for(size_t i = 1; i < _buffer.size(); ++i) {
		Flit * bf = _buffer[i];
		if(bf->pri > df->pri) df = bf;
      }
      if((df != f) && (df->watch || f->watch)) {
		*gWatchOut << GetSimTime() << " | " << FullName() << " | "
		    << "Flit " << df->id
		    << " donates priority to flit " << f->id
		    << "." << endl;
      }
      f = df;
    }
    if(f->watch)
      *gWatchOut << GetSimTime() << " | " << FullName() << " | "
		  << "Flit " << f->id
		  << " sets priority to " << f->pri
		  << "." << endl;
    _pri = f->pri;
  }
}


void VC::Route( tRoutingFunction rf, const Router* router, const Flit* f, int in_channel )
{
  rf( router, f, in_channel, _route_set, false );//route_set is outputSet
  _out_port = -1;
  _out_vc = -1;
}

// ==== Debug functions ====

void VC::SetWatch( bool watch )
{
  _watched = watch;
}

bool VC::IsWatched( ) const
{
  return _watched;
}

void VC::Display( ostream & os ) const
{
  if ( _state != VC::idle ) {
    os << FullName() << ": "
       << " state: " << VCSTATE[_state];
    if(_state == VC::active) {
      os << " out_port: " << _out_port
	 << " out_vc: " << _out_vc;
    }
    os << " fill: " << _buffer.size();
    if(!_buffer.empty()) {
      os << " front: " << _buffer.front()->id;
    }
    os << " pri: " << _pri;
    os << endl;
  }
}
